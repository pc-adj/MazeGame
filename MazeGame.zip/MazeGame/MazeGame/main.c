#include <stdio.h>
#include <stdlib.h>
#include <conio.h>

#define MAP_MAX_WIDTH	10
#define MAP_MAX_HEIGHT	10

#define KEY_LEFT	75
#define KEY_RIGHT	77
#define KEY_DOWN	80
#define KEY_UP		72

#define ROAD	0
#define WALL	1
#define PLAYER	2
#define Finish	3

int map[MAP_MAX_WIDTH][MAP_MAX_HEIGHT] = {
	{1, 1, 1, 1, 1, 1, 1, 1, 1, 1},
	{1, 1, 1, 1, 1, 1, 0, 0, 0, 1},
	{1, 0, 0, 0, 0, 1, 3, 1, 0, 1},
	{1, 0, 1, 1, 0, 1, 1, 0, 0, 1},
	{1, 0, 1, 0, 0, 0, 1, 0, 1, 1},
	{1, 0, 1, 1, 1, 0, 1, 0, 0, 1},
	{1, 0, 0, 0, 1, 0, 1, 1, 0, 1},
	{1, 1, 1, 0, 1, 0, 0, 0, 0, 1},
	{1, 2, 0, 0, 1, 0, 1, 1, 0, 1},
	{1, 1, 1, 1, 1, 1, 1, 1, 1, 1}
};

void MoveLeft();
void MoveRight();
void MoveDown();
void MoveUp();
void DrawGame();

int playerX = 1;
int playerY = 8;
int game = 0;

int main()
{
	DrawGame();

	while (game == 0)
	{
		if (_kbhit())
		{
			system("cls");
			int kbNum = getch();
			if (kbNum == 224)
			{
				kbNum = getch();
				switch (kbNum)
				{
				case KEY_LEFT:
					MoveLeft();
					break;
				case KEY_DOWN:
					MoveDown();
					break;
				case KEY_RIGHT:
					MoveRight();
					break;
				case KEY_UP:
					MoveUp();
					break;
				default:
					break;
				}
			}

			DrawGame();
		}
	}
	printf("����� �̷ο��� Ż���ϼ̽��ϴ� �����մϴ� ���� �����ؿ�(?)");
	return 0;

}

void MoveLeft()
{
	if (map[playerY][playerX - 1] != WALL)
	{
		if (map[playerY][playerX - 1] == Finish) {
			game = 1;
		}
		
		map[playerY][playerX] = 0;
		map[playerY][playerX - 1] = PLAYER;

		playerX--;
	}
}

void MoveRight()
{
	if (map[playerY][playerX + 1] != WALL)
	{
		if (map[playerY][playerX + 1] == Finish) {
			game = 1;
		}
		map[playerY][playerX] = 0;
		map[playerY][playerX + 1] = PLAYER;

		playerX++;
	}
}

void MoveDown()
{
	if (map[playerY + 1][playerX] != WALL)
	{
		if (map[playerY+1][playerX] == Finish) {
			game = 1;
		}
		map[playerY][playerX] = 0;
		map[playerY + 1][playerX] = PLAYER;

		playerY++;
	}
}

void MoveUp()
{
	if (map[playerY - 1][playerX] != WALL)
	{
		if (map[playerY - 1][playerX] == Finish) {
			game = 1;
		}
		map[playerY][playerX] = 0;
		map[playerY - 1][playerX] = PLAYER;

		playerY--;
	}
}

void DrawGame()
{
	for (int i = 0; i < MAP_MAX_HEIGHT; i++)
	{
		for (int j = 0; j < MAP_MAX_WIDTH; j++)
		{
			if (map[i][j] == WALL)
				printf("��");
			else if (map[i][j] == PLAYER)
				printf("��");
			else if (map[i][j] == Finish)
				printf("��");
			else
				printf("  ");
		}
		
		printf("\n");
	}
}